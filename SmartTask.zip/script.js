document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("app").innerText = "SmartTask қосымшасы іске қосылды!";
});
